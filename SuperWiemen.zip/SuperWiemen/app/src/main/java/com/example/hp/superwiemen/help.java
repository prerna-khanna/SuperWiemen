package com.example.hp.superwiemen;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class help extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help);

        String[] myList1 = {"Enter Emergency Contacts", "Edit details"};
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, R.layout.list_layout, myList1);
        final ListView list1 = (ListView)findViewById(R.id.list1);
        list1.setAdapter(adapter1);
        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                int item1 = list1.getPositionForView(view);
                if(item1 == 1) {
                    Intent intent = new Intent(help.this, details.class);
                    startActivity(intent);
                }
                if(item1 == 0) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=IE68laYFpvk")));
                }

            }
        });
    }
}
