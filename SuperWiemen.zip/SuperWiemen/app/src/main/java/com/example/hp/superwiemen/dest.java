package com.example.hp.superwiemen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class dest extends Activity {
 private Button upload;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dest);
        upload = findViewById(R.id.destUpload);

        final String name = MainActivity.returnName();

        final EditText dest = (EditText) findViewById(R.id.destination);

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String destination = dest.getText().toString();

                System.out.println("dest is " + dest);
                //MainActivity.mDatabaseRef.child(name).child("dest").setValue(destination);

                        Intent intent = new Intent(dest.this, Result.class);
                        startActivity(intent);
            }
        });
    }
}

