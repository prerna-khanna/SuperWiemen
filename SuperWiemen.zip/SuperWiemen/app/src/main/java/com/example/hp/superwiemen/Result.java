package com.example.hp.superwiemen;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;




public class Result extends Activity {
    String rate;
    String ans;
    Button mButton;
    Button route;
    public static DatabaseReference mRef;
    String name;
    Button mShare;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);
        name = MainActivity.returnName();
        System.out.println("in result");

        mRef = FirebaseDatabase.getInstance().getReference("uploads/" + name + "/rate");
        mRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                rate = dataSnapshot.getValue(String.class);
                Log.d("ADebugTag", "flag: " + String.valueOf(rate));
                System.out.println("flag ans " + rate);



                mButton = findViewById(R.id.round);

                mButton.setText(rate);
                Log.d("ADebugTag", "AQI: " + String.valueOf(ans));

                int warn = Integer.parseInt(rate);
                if (warn == 1) {
                    mButton.getBackground().setColorFilter(Color.rgb(0, 204, 102), PorterDuff.Mode.SRC_ATOP);
                } else if (warn == 2) {
                    mButton.getBackground().setColorFilter(Color.rgb(0, 204, 0), PorterDuff.Mode.SRC_ATOP);
                } else if (warn == 3) {
                    mButton.getBackground().setColorFilter(Color.rgb(255, 204, 0), PorterDuff.Mode.SRC_ATOP);
                } else if (warn == 4) {
                    mButton.getBackground().setColorFilter(Color.rgb(255, 102, 0), PorterDuff.Mode.SRC_ATOP);
                } else if (warn == 5) {
                    mButton.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
                } else {
                    mButton.getBackground().setColorFilter(Color.rgb(128, 0, 0), PorterDuff.Mode.SRC_ATOP);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }

        });


        route = findViewById(R.id.route);
        mShare = findViewById(R.id.share);

        route.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Result.this, MapsActivity.class);
                startActivity(intent);
            }
        });

        mShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double latitude = 28.123;
                Double longitude = 77.123;
                String url = "https://www.google.com/maps/@"+latitude+","+longitude+",15z/data=!3m1!4b1!4m2!7m1!2e1?hl=en";

                Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"prerna.khanna@gmail.com", "ishani.janveja@gmaail.com"});
                intent.putExtra(Intent.EXTRA_TEXT, url);
                intent.putExtra(Intent.EXTRA_SUBJECT, "Live Location Tracking Link");

                startActivity(intent);
            }
        });


    }
    }

